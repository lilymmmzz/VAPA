import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/notes_provider.dart';
import '../providers/reminders_provider.dart';
import '../providers/mood_provider.dart';
import 'notes/notes_screen.dart';
import 'reminders/reminders_screen.dart';
import 'voice/voice_screen.dart';
import 'mood/mood_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = [
    const NotesScreen(),
    const RemindersScreen(),
    const VoiceScreen(),
    const MoodScreen(),
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      final userId = authProvider.user?.uid;
      if (userId != null) {
        Provider.of<NotesProvider>(context, listen: false).loadNotes(userId);
        Provider.of<RemindersProvider>(context, listen: false)
            .loadReminders(userId);
        Provider.of<MoodProvider>(context, listen: false).loadMoods(userId);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final moodProvider = Provider.of<MoodProvider>(context);

    return Scaffold(
      backgroundColor: const Color(0xFF1A1A2E),
      appBar: AppBar(
        backgroundColor: const Color(0xFF12122A),
        elevation: 0,
        title: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF26215C),
                border:
                    Border.all(color: const Color(0xFF534AB7), width: 1.5),
              ),
              child:
                  const Icon(Icons.mic, color: Color(0xFF7F77DD), size: 16),
            ),
            const SizedBox(width: 10),
            const Text(
              'VAPA',
              style: TextStyle(
                color: Color(0xFFAFA9EC),
                fontWeight: FontWeight.bold,
                letterSpacing: 4,
                fontSize: 20,
              ),
            ),
          ],
        ),
        actions: [
          // Show mood prompt if not logged today
          if (!moodProvider.hasLoggedToday)
            IconButton(
              icon: const Text('😊', style: TextStyle(fontSize: 20)),
              onPressed: () {
                setState(() => _currentIndex = 3);
              },
              tooltip: 'Log your mood',
            ),
          IconButton(
            icon: const Icon(Icons.logout, color: Color(0xFF534AB7)),
            onPressed: () async {
              Provider.of<NotesProvider>(context, listen: false)
                  .clearNotes();
              Provider.of<RemindersProvider>(context, listen: false)
                  .clearReminders();
              Provider.of<MoodProvider>(context, listen: false)
                  .clearMoods();
              await authProvider.logout();
            },
          ),
        ],
      ),
      body: _screens[_currentIndex],
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: Color(0xFF12122A),
          border: Border(
            top: BorderSide(color: Color(0xFF3C3489), width: 0.5),
          ),
        ),
        child: NavigationBar(
          backgroundColor: const Color(0xFF12122A),
          selectedIndex: _currentIndex,
          onDestinationSelected: (index) {
            setState(() => _currentIndex = index);
          },
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.note_outlined, color: Color(0xFF534AB7)),
              selectedIcon: Icon(Icons.note, color: Color(0xFFAFA9EC)),
              label: 'Notes',
            ),
            NavigationDestination(
              icon: Icon(Icons.alarm_outlined, color: Color(0xFF534AB7)),
              selectedIcon: Icon(Icons.alarm, color: Color(0xFFAFA9EC)),
              label: 'Reminders',
            ),
            NavigationDestination(
              icon: Icon(Icons.mic_outlined, color: Color(0xFF534AB7)),
              selectedIcon: Icon(Icons.mic, color: Color(0xFFAFA9EC)),
              label: 'Voice',
            ),
            NavigationDestination(
              icon: Icon(Icons.mood_outlined, color: Color(0xFF534AB7)),
              selectedIcon: Icon(Icons.mood, color: Color(0xFFAFA9EC)),
              label: 'Mood',
            ),
          ],
        ),
      ),
    );
  }
}