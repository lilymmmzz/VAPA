dynamic startWebSpeech(Function(String, bool) onResult, Function(String) onError) {
  return null;
}

void stopWebSpeech(dynamic recognition) {}