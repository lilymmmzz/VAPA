import 'dart:js_interop';

@JS('startSpeechRecognition')
external JSAny? startSpeechRecognition(JSFunction onResult, JSFunction onError);

@JS('stopSpeechRecognition')
external void stopSpeechRecognition(JSAny? recognition);

dynamic startWebSpeech(Function(String, bool) onResult, Function(String) onError) {
  return startSpeechRecognition(
    ((JSString transcript, JSBoolean isFinal) {
      onResult(transcript.toDart, isFinal.toDart);
    }).toJS,
    ((JSString error) {
      onError(error.toDart);
    }).toJS,
  );
}

void stopWebSpeech(dynamic recognition) {
  stopSpeechRecognition(recognition as JSAny?);
}
