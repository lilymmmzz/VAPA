import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:provider/provider.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:flutter_tts/flutter_tts.dart';
import '../../providers/auth_provider.dart';
import '../../providers/notes_provider.dart';
import '../../providers/reminders_provider.dart';

import 'voice_screen_web.dart' if (dart.library.io) 'voice_screen_stub.dart';

class VoiceScreen extends StatefulWidget {
  const VoiceScreen({super.key});

  @override
  State<VoiceScreen> createState() => _VoiceScreenState();
}

class _VoiceScreenState extends State<VoiceScreen> {
  final SpeechToText _speechToText = SpeechToText();
  final FlutterTts _flutterTts = FlutterTts();
  final TextEditingController _textController = TextEditingController();
  bool _isListening = false;
  String _transcribedText = '';
  String _statusMessage = 'Tap the microphone to start';
  final List<String> _commandHistory = [];
  dynamic _webRecognition;

  @override
  void initState() {
    super.initState();
    _initSpeech();
    _initTts();
  }

  Future<void> _initSpeech() async {
    if (kIsWeb) {
      setState(() {});
      return;
    }
    await _speechToText.initialize(
      onError: (error) {
        setState(() {
          _statusMessage = 'Tap the microphone to start';
        });
      },
    );
    setState(() {});
  }

  Future<void> _initTts() async {
    await _flutterTts.setLanguage('en-US');
    await _flutterTts.setSpeechRate(0.9);
    await _flutterTts.setVolume(1.0);
    await _flutterTts.setPitch(1.8);

    if (kIsWeb) {
      await _flutterTts.setVoice({
        'name': 'Google US English',
        'locale': 'en-US'
      });
    } else {
      List<dynamic> voices = await _flutterTts.getVoices;
      var femaleVoice = voices.firstWhere(
        (voice) =>
            voice['name'].toString().toLowerCase().contains('female') ||
            voice['name'].toString().toLowerCase().contains('samantha') ||
            voice['name'].toString().toLowerCase().contains('zira') ||
            voice['name'].toString().toLowerCase().contains('victoria'),
        orElse: () => null,
      );
      if (femaleVoice != null) {
        await _flutterTts.setVoice({
          'name': femaleVoice['name'],
          'locale': femaleVoice['locale'],
        });
      }
    }
  }

  Future<void> _speak(String text) async {
    await _flutterTts.speak(text);
  }

  Future<void> _startListening() async {
    setState(() {
      _isListening = true;
      _statusMessage = 'Listening...';
      _transcribedText = '';
    });

    if (kIsWeb) {
      _webRecognition = startWebSpeech(
        (String transcript, bool isFinal) {
          setState(() {
            _transcribedText = transcript;
          });
          if (isFinal) {
            _processCommand(transcript);
          }
        },
        (String error) {
          setState(() {
            _isListening = false;
            _statusMessage = 'Could not hear you. Try again or type below.';
          });
        },
      );
      return;
    }

    await _speechToText.listen(
      onResult: (result) {
        setState(() {
          _transcribedText = result.recognizedWords;
        });
        if (result.finalResult) {
          _processCommand(_transcribedText);
        }
      },
      listenFor: const Duration(seconds: 10),
      pauseFor: const Duration(seconds: 3),
    );
  }

  Future<void> _stopListening() async {
    if (kIsWeb) {
      stopWebSpeech(_webRecognition);
    } else {
      await _speechToText.stop();
    }
    setState(() {
      _isListening = false;
      _statusMessage = 'Tap the microphone to start';
    });
  }

  Future<void> _processCommand(String command) async {
    final lowerCommand = command.toLowerCase().trim();
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final notesProvider = Provider.of<NotesProvider>(context, listen: false);
    final remindersProvider =
        Provider.of<RemindersProvider>(context, listen: false);
    final userId = authProvider.user?.uid ?? '';

    setState(() {
      _isListening = false;
      _statusMessage = 'Processing...';
      _transcribedText = command;
    });

    if (lowerCommand.contains('create note') ||
        lowerCommand.contains('add note') ||
        lowerCommand.contains('new note')) {
      String title = lowerCommand
          .replaceAll('create note', '')
          .replaceAll('add note', '')
          .replaceAll('new note', '')
          .trim();
      if (title.isEmpty) title = 'Voice Note';
      await notesProvider.createNote(
          userId, title, 'Created via voice command');
      final response = 'Note "$title" created successfully';
      setState(() {
        _statusMessage = response;
        _commandHistory.insert(0, '📝 $response');
      });
      await _speak(response);
    } else if (lowerCommand.contains('list notes') ||
        lowerCommand.contains('show notes') ||
        lowerCommand.contains('my notes')) {
      final count = notesProvider.notes.length;
      final response = 'You have $count note${count == 1 ? '' : 's'}';
      setState(() {
        _statusMessage = response;
        _commandHistory.insert(0, '📋 $response');
      });
      await _speak(response);
    } else if (lowerCommand.contains('create reminder') ||
        lowerCommand.contains('add reminder') ||
        lowerCommand.contains('new reminder') ||
        lowerCommand.contains('remind me')) {
      String title = lowerCommand
          .replaceAll('create reminder', '')
          .replaceAll('add reminder', '')
          .replaceAll('new reminder', '')
          .replaceAll('remind me', '')
          .trim();
      if (title.isEmpty) title = 'Voice Reminder';
      final scheduledDateTime =
          DateTime.now().add(const Duration(hours: 1));
      await remindersProvider.createReminder(
          userId, title, 'Created via voice command', scheduledDateTime);
      final response = 'Reminder "$title" created for one hour from now';
      setState(() {
        _statusMessage = response;
        _commandHistory.insert(0, '⏰ $response');
      });
      await _speak(response);
    } else if (lowerCommand.contains('list reminders') ||
        lowerCommand.contains('show reminders') ||
        lowerCommand.contains('my reminders')) {
      final count = remindersProvider.reminders.length;
      final response =
          'You have $count reminder${count == 1 ? '' : 's'}';
      setState(() {
        _statusMessage = response;
        _commandHistory.insert(0, '📋 $response');
      });
      await _speak(response);
    } else if (lowerCommand.contains('help') ||
        lowerCommand.contains('what can you do')) {
      const response =
          'You can say: create note, list notes, create reminder, list reminders, or help';
      setState(() {
        _statusMessage = response;
        _commandHistory.insert(0, '❓ Help requested');
      });
      await _speak(response);
    } else if (lowerCommand.isNotEmpty) {
      final response =
          'Sorry, I did not understand: "$command". Try: create note, list notes, create reminder, list reminders';
      setState(() {
        _statusMessage = response;
        _commandHistory.insert(0, '❌ Unknown: $command');
      });
      await _speak(response);
    }

    setState(() {
      if (_statusMessage == 'Processing...') {
        _statusMessage = 'Tap the microphone to start';
      }
    });
  }

  @override
  void dispose() {
    _speechToText.stop();
    _flutterTts.stop();
    _textController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            const SizedBox(height: 24),
            Text(
              _statusMessage,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: _isListening
                        ? Theme.of(context).colorScheme.primary
                        : Colors.grey[600],
                  ),
            ),
            const SizedBox(height: 16),
            if (_transcribedText.isNotEmpty)
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Theme.of(context)
                      .colorScheme
                      .surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  _transcribedText,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 16),
                ),
              ),
            const SizedBox(height: 32),
            GestureDetector(
              onTap: _isListening ? _stopListening : _startListening,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                width: _isListening ? 120 : 100,
                height: _isListening ? 120 : 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _isListening
                      ? Colors.red
                      : Theme.of(context).colorScheme.primary,
                  boxShadow: [
                    BoxShadow(
                      color: (_isListening
                              ? Colors.red
                              : Theme.of(context).colorScheme.primary)
                          .withValues(alpha: 0.3),
                      blurRadius: _isListening ? 30 : 10,
                      spreadRadius: _isListening ? 10 : 2,
                    ),
                  ],
                ),
                child: Icon(
                  _isListening ? Icons.mic : Icons.mic_none,
                  size: 48,
                  color: Colors.white,
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _isListening ? 'Tap to stop' : 'Tap to speak',
              style: TextStyle(color: Colors.grey[500]),
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _textController,
                    decoration: InputDecoration(
                      hintText: 'Or type a command here...',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onSubmitted: (value) {
                      if (value.trim().isNotEmpty) {
                        _processCommand(value.trim());
                        _textController.clear();
                      }
                    },
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  onPressed: () {
                    if (_textController.text.trim().isNotEmpty) {
                      _processCommand(_textController.text.trim());
                      _textController.clear();
                    }
                  },
                  icon: const Icon(Icons.send),
                  style: IconButton.styleFrom(
                    backgroundColor:
                        Theme.of(context).colorScheme.primary,
                    foregroundColor: Colors.white,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey[300]!),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Voice Commands:',
                    style:
                        Theme.of(context).textTheme.titleSmall?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                  ),
                  const SizedBox(height: 8),
                  const Text('• "Create note [title]"'),
                  const Text('• "List notes"'),
                  const Text('• "Create reminder [title]"'),
                  const Text('• "List reminders"'),
                  const Text('• "Help"'),
                ],
              ),
            ),
            const SizedBox(height: 16),
            if (_commandHistory.isNotEmpty) ...[
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Recent Commands:',
                  style:
                      Theme.of(context).textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                ),
              ),
              const SizedBox(height: 8),
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _commandHistory.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Text(
                      _commandHistory[index],
                      style: TextStyle(color: Colors.grey[600]),
                    ),
                  );
                },
              ),
            ],
          ],
        ),
      ),
    );
  }
}